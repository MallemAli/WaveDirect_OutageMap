package com.example.wavedirect_outage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
